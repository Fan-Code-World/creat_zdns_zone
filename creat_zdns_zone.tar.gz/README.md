# creat_zdns_zone
BIND_zone  or  Windwos_zone transfer  Zddi_zone

 creat_zdns_zone v1.1.1
#将zone文件放至 ‘zone_file’ 目录中
#在zddi-master后台使用以下命令将区文件批量创建至zddi
PYTHONPATH=./lib/site-packages  python     creat_zdns_zone.py          
